package br.com.Minitwitter.repository;

import org.springframework.data.repository.CrudRepository;

import br.com.Minitwitter.model.Role;



public interface RoleRepository extends CrudRepository<Role, String>{

}
