package br.com.Minitwitter.repository;

import org.springframework.data.repository.CrudRepository;

import br.com.Minitwitter.model.Notification;


public interface NotificationRepository extends CrudRepository<Notification, Long> {

}
