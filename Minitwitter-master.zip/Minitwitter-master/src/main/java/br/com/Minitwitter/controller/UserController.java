package br.com.Minitwitter.controller;

import java.util.Base64;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import br.com.Minitwitter.model.Role;
import br.com.Minitwitter.model.Tweet;
import br.com.Minitwitter.model.User;
import br.com.Minitwitter.service.RoleService;
import br.com.Minitwitter.service.UserService;
import groovy.time.BaseDuration.From;



@Controller
public class UserController {
  
  private UserService userService;
  private RoleService roleService;
  
  @Autowired
  public void setUserService(UserService userService) {
    this.userService = userService;
  }
  
  @Autowired
  public void setRoleService(RoleService roleService) {
    this.roleService = roleService;
  }
  
  @Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;

  /**
   * a post method to create a new user
   * 
   * @param user valid
   * @param br injected
   * @return a redirect to the index page
   */
  @PostMapping("/user")
  public String createUser(@Valid @ModelAttribute User user, BindingResult br) {
    if (userService.contains(user))
      br.rejectValue("username", "error.user", "There is a user with this username.");
    if(br.hasErrors())
      return "users/form";
    Role role = new Role();
    
    role.setRole("ROLE_NORMAL");
    
    if(!roleService.hasRole(role.getAuthority())){
      roleService.save(role);
    }
    String encodedPassword = bCryptPasswordEncoder.encode(user.getPassword());
    
    user.addRole(role);
    
    user.setUsername(user.getUsername().toLowerCase());
    user.setPassword(encodedPassword);
    
    userService.save(user);
    
    
    return "redirect:/";
  }
  
  /**
   * get method to create a new user from a form
   * 
   * @param model injected
   * @return form's model path
   */
  @GetMapping("/user")
  public String userForm(Model model) {
    User user = new User();
    model.addAttribute("user", user);
    
    return "users/form";
    
  }
  

  /**
   * get method to the login page
   * 
   * @param model injected
   * @return login's model path
   */
  @GetMapping("/login")
  public String loginForm(Model model) {
    User user = new User();
    model.addAttribute("user", user);
       
    return "users/login";
  }
  
  /**
   * a get method to see the details of a user
   * 
   * @param username of a user that contains in the system
   * @param model injeted
   * @return details' model path
   */
  @GetMapping("/{username}")
  public String profileDetails(@PathVariable("username") String username, Model model) {
	 
    Authentication auth = SecurityContextHolder.getContext()
        .getAuthentication();
    String currentUsername = auth.getName().toLowerCase();
    username = username.toLowerCase();
    User currentUser = new User();
    currentUser.setUsername(currentUsername);
    boolean containsUser = userService.contains(currentUser);
    if (!containsUser)
      return "redirect:/";
    if(currentUsername.equals(username))
      model.addAttribute("isOwner", true);
    else
      model.addAttribute("isOwner", false);
    
    User user = userService.loadUserByUsername(username.toLowerCase());
    
    if(containsUser){
      currentUser = userService.loadUserByUsername(currentUsername);
      boolean isFollowing = currentUser.isFollowing(user);
      model.addAttribute("isFollowing", isFollowing);
      
    } else {
      model.addAttribute("isFollowing", false);
    }
    
    List<Tweet> tweets = user.getTweets();
    
    model.addAttribute("tweets", tweets);
    
    model.addAttribute("user", user);
    
    model.addAttribute("following", user.getFollowing().size());
    
    model.addAttribute("followers", user.getFollowers().size());
  
    byte[] image = user.getImage();
   // byte[] encode = java.util.Base64.getEncoder().encode(image);
   // model.addAttribute("image", new String(encode, "UTF-8"));
    try {
       byte[] encodeBase64 = Base64.getEncoder().encode(image);
       String base64Encoded = new String(encodeBase64, "UTF-8");
       model.addAttribute("userImage", base64Encoded );
     } catch (Exception e) {
          return "users/details";
      }

    return "users/details";
  }
  
  /**
   * A post method to the current user follow other user
   * 
   * @param username of a user that contains in the system
   * @return a redirect to the index page
   */
  @PostMapping("/follow")
  public String follow(@RequestParam("username") String username) {
    Authentication auth = SecurityContextHolder.getContext()
        .getAuthentication();
    String currentUsername = auth.getName().toLowerCase();
    if(currentUsername.equals(username))
      return "redirect:/" + username;
    
    User user = userService.loadUserByUsername(username);
    User currentUser = userService.loadUserByUsername(currentUsername);
    
    if(!currentUser.isFollowing(user))
      currentUser.addFollowing(user);
    userService.save(currentUser);
    
    
    return "redirect:/" + username;
  }

  /**
   * A post method to the current user unfollow other user
   * 
   * @param username of a user that contains in the system
   * @return a redirect to the index page
   */
  @PostMapping("/unfollow")
  public String unfollow(@RequestParam("username") String username) {
    
    Authentication auth = SecurityContextHolder.getContext()
        .getAuthentication();
    String currentUsername = auth.getName().toLowerCase();
    if(currentUsername.equals(username))
      return "redirect:/" + username;
    
    User user = userService.loadUserByUsername(username);
    User currentUser = userService.loadUserByUsername(currentUsername);
    
    if(currentUser.isFollowing(user))
      currentUser.removeFollowing(user);
    
    userService.save(currentUser);
    
    return "redirect:/" + username;
  }
  @PostMapping("/changepass")
  public String editprofileDetails (Model model) {
	    Authentication auth = SecurityContextHolder.getContext()
	        .getAuthentication();
	    String currentUsername = auth.getName().toLowerCase();
	    User currentUser = new User();
	    currentUser.setUsername(currentUsername);
	    boolean containsUser = userService.contains(currentUser);
	    if (!containsUser)
	      return "redirect:/";
	    return "users/changepass";
	  }
  
  
  @GetMapping("/ProfilePic")
  public String ProfilePic (@Valid @ModelAttribute User user, 
		  BindingResult result, Model model, @RequestParam String userImage1) {
	    Authentication auth = SecurityContextHolder.getContext()
	        .getAuthentication();
	    String currentUsername = auth.getName().toLowerCase();
	    User currentUser = new User();
	    currentUser.setUsername(currentUsername);
	    boolean containsUser = userService.contains(currentUser);
	    if (!containsUser)
	      return "redirect:/";
	    String imagelink = userImage1;
	    System.out.println("User Image from html :"+userImage1);
	    model.addAttribute("imageUpload", imagelink); 
	    return "/users/UploadProfilePic";
	  }
  
 @PostMapping("/changepass/{username}")
  public String updateUser(@RequestParam  String Npassword , String currentpassword, @Valid @ModelAttribute User user, 
		  BindingResult result, Model model) {
	 Authentication auth = SecurityContextHolder.getContext()
		        .getAuthentication();
	
	 String currentUsername = auth.getName().toLowerCase();
	 User user1 = userService.loadUserByUsername(currentUsername);
	 String encodedPassword = bCryptPasswordEncoder.encode(user1.getPassword());
	 String Dbpass = user1.getPassword();
	 
	 
	    if ((BCrypt.checkpw(Dbpass, currentpassword)) && (!BCrypt.checkpw(Dbpass, Npassword))) {
		    
			user1.setPassword(user.hashPassword(Npassword));
			userService.save(user1);
			return "redirect:/";
	    }
	    else
	    {
	    	
	    	return "users/changepass";
	    }

  }
 

 @PostMapping("/fileupload/{username}")
 public String fileUpload(@RequestParam String imageUpload, MultipartFile file, @Valid @ModelAttribute User user,BindingResult result, Model model) {
 	    	try {
				 Authentication auth = SecurityContextHolder.getContext()
					        .getAuthentication();
				 String currentUsername = auth.getName().toLowerCase();
 	     	 	User user1 = userService.loadUserByUsername(currentUsername); 	  
 	     	 	System.out.print("Testing From.class..");
 	     	 	System.out.println(imageUpload);
 	     	 	byte[] image = file.getBytes();
 	     	 	user1.setImage(image);
	    	    try {
 	     	       byte[] encodeBase64 = Base64.getEncoder().encode(image);
 	     	       String base64Encoded = new String(encodeBase64, "UTF-8");
 	     	       model.addAttribute("userImage", base64Encoded );
 	     	     } catch (Exception e) {
 	     	          return "users/details";
 	     	      }	     	 	
 	 			int saveImage = userService.saveImage(user1);
 	            if (saveImage == 1) {
 	//                return "redirect:/";
 	            	return "redirect:/"+currentUsername;
 	            } else {
 	                return "users/details";
 	            }
 	        } catch (Exception e) {
 	            return "users/details";
 	        }
 	    }

 @PostMapping("/preview/{username}")
 public String filepreview(@RequestParam ("imageUpload") MultipartFile file, @Valid @ModelAttribute User user,BindingResult result, Model model) {
 	    	try {
				 Authentication auth = SecurityContextHolder.getContext()
					        .getAuthentication();
				 String currentUsername = auth.getName().toLowerCase();
 	     	 	User user1 = userService.loadUserByUsername(currentUsername); 	          
 	     	 	
 	     	 	byte[] image = file.getBytes();
 	     	 	user1.setImage(image);
	    	    try {
 	     	       byte[] encodeBase64 = Base64.getEncoder().encode(image);
 	     	       String base64Encoded = new String(encodeBase64, "UTF-8");
 	     	       model.addAttribute("userImage", base64Encoded );
 	     	     } catch (Exception e) {
 	     	          return "users/details";
 	     	      }	     	 	
 	/* 			int saveImage = userService.saveImage(user1);
 	            if (saveImage == 1) {
 	              return "redirect:/";
 	            	return "redirect:/"+currentUsername;
 	            } else {
 	                return "users/details";
 	            } */
 	        } catch (Exception e) {
 	            return "users/details";
 	        }
 	    	 return "users/details";
 	    }
 @GetMapping("/getImage")
 public String getDbDetils(@Valid @ModelAttribute User user ,Model model,BindingResult result) {
     try {
    	 Authentication auth = SecurityContextHolder.getContext()
   		        .getAuthentication();
      	 String currentUsername = auth.getName().toLowerCase();
      	 User user1 = userService.loadUserByUsername(currentUsername); 
       
         byte[] image = user1.getImage();
        // byte[] encode = java.util.Base64.getEncoder().encode(image);
        // model.addAttribute("image", new String(encode, "UTF-8"));

         byte[] encodeBase64 = Base64.getEncoder().encode(image);
         String base64Encoded = new String(encodeBase64, "UTF-8");
         model.addAttribute("userImage", base64Encoded );
         System.out.println(base64Encoded);
         return "users/details";
     } catch (Exception e) {
         model.addAttribute("message", "Error in getting image");
         return "users/details";
     }
 }
 }
  
